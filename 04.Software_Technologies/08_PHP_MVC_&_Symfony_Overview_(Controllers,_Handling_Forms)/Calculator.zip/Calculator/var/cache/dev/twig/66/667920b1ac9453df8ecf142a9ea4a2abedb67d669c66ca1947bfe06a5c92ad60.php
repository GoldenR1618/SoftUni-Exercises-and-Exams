<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_582d620e788fdbe58ec5298edc9ae3c4fa452ecd15f60d45b81de28f7e5547e8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1351ccc8fdbe7cdc052f1a5646be3c89b7a60ab615afa1e5c9d65859275e508b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1351ccc8fdbe7cdc052f1a5646be3c89b7a60ab615afa1e5c9d65859275e508b->enter($__internal_1351ccc8fdbe7cdc052f1a5646be3c89b7a60ab615afa1e5c9d65859275e508b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1351ccc8fdbe7cdc052f1a5646be3c89b7a60ab615afa1e5c9d65859275e508b->leave($__internal_1351ccc8fdbe7cdc052f1a5646be3c89b7a60ab615afa1e5c9d65859275e508b_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_541580976bffda49165f38479f59bd11699c105a1fc970430a17712da7639eb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_541580976bffda49165f38479f59bd11699c105a1fc970430a17712da7639eb2->enter($__internal_541580976bffda49165f38479f59bd11699c105a1fc970430a17712da7639eb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_541580976bffda49165f38479f59bd11699c105a1fc970430a17712da7639eb2->leave($__internal_541580976bffda49165f38479f59bd11699c105a1fc970430a17712da7639eb2_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_11b51c3a997fcf15995a3b8635ec589e4bd4f74f6d798941886f4db62077e0b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11b51c3a997fcf15995a3b8635ec589e4bd4f74f6d798941886f4db62077e0b7->enter($__internal_11b51c3a997fcf15995a3b8635ec589e4bd4f74f6d798941886f4db62077e0b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_11b51c3a997fcf15995a3b8635ec589e4bd4f74f6d798941886f4db62077e0b7->leave($__internal_11b51c3a997fcf15995a3b8635ec589e4bd4f74f6d798941886f4db62077e0b7_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_181094935d7676af62b37f92ae7e7207f853b61a2faec5a93957b969beb50d1b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_181094935d7676af62b37f92ae7e7207f853b61a2faec5a93957b969beb50d1b->enter($__internal_181094935d7676af62b37f92ae7e7207f853b61a2faec5a93957b969beb50d1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_181094935d7676af62b37f92ae7e7207f853b61a2faec5a93957b969beb50d1b->leave($__internal_181094935d7676af62b37f92ae7e7207f853b61a2faec5a93957b969beb50d1b_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
