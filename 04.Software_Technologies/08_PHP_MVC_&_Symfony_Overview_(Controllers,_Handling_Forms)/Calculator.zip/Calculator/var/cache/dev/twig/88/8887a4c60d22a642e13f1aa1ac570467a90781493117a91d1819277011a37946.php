<?php

/* base.html.twig */
class __TwigTemplate_d195b86467614ddfb00a2db19d442fd892faeece8aa0a47f68efa29e78663646 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8974bfae9f983f59bb8997130b5030a7726800dd233f6526d51f159f8c5657fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8974bfae9f983f59bb8997130b5030a7726800dd233f6526d51f159f8c5657fb->enter($__internal_8974bfae9f983f59bb8997130b5030a7726800dd233f6526d51f159f8c5657fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>


";
        // line 51
        $this->displayBlock('javascripts', $context, $blocks);
        // line 57
        echo "
</body>
</html>
";
        
        $__internal_8974bfae9f983f59bb8997130b5030a7726800dd233f6526d51f159f8c5657fb->leave($__internal_8974bfae9f983f59bb8997130b5030a7726800dd233f6526d51f159f8c5657fb_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_a630179f109c7e5950eb15e5b159cd8dd099786d9ade301d552fc6dec75bd4eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a630179f109c7e5950eb15e5b159cd8dd099786d9ade301d552fc6dec75bd4eb->enter($__internal_a630179f109c7e5950eb15e5b159cd8dd099786d9ade301d552fc6dec75bd4eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_a630179f109c7e5950eb15e5b159cd8dd099786d9ade301d552fc6dec75bd4eb->leave($__internal_a630179f109c7e5950eb15e5b159cd8dd099786d9ade301d552fc6dec75bd4eb_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_09b8c7e72e3eccd9b004db29422b69440b6a01f5b6ee9ba11191c2ec267afed3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_09b8c7e72e3eccd9b004db29422b69440b6a01f5b6ee9ba11191c2ec267afed3->enter($__internal_09b8c7e72e3eccd9b004db29422b69440b6a01f5b6ee9ba11191c2ec267afed3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_09b8c7e72e3eccd9b004db29422b69440b6a01f5b6ee9ba11191c2ec267afed3->leave($__internal_09b8c7e72e3eccd9b004db29422b69440b6a01f5b6ee9ba11191c2ec267afed3_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_931d72f4de87d9432ea34248f1d55a59cef4a04b6651196cc53cd7fa2b9ee8f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_931d72f4de87d9432ea34248f1d55a59cef4a04b6651196cc53cd7fa2b9ee8f5->enter($__internal_931d72f4de87d9432ea34248f1d55a59cef4a04b6651196cc53cd7fa2b9ee8f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_931d72f4de87d9432ea34248f1d55a59cef4a04b6651196cc53cd7fa2b9ee8f5->leave($__internal_931d72f4de87d9432ea34248f1d55a59cef4a04b6651196cc53cd7fa2b9ee8f5_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_ec354ca3aa2ed84dcc489d22f344ae830e86267701df422585eb46b24ed9de94 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec354ca3aa2ed84dcc489d22f344ae830e86267701df422585eb46b24ed9de94->enter($__internal_ec354ca3aa2ed84dcc489d22f344ae830e86267701df422585eb46b24ed9de94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_ec354ca3aa2ed84dcc489d22f344ae830e86267701df422585eb46b24ed9de94->leave($__internal_ec354ca3aa2ed84dcc489d22f344ae830e86267701df422585eb46b24ed9de94_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_3dcbf92960074b7a8c1236c0cb50a82935e0f67fa7f83d45b1a75c1637344c60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3dcbf92960074b7a8c1236c0cb50a82935e0f67fa7f83d45b1a75c1637344c60->enter($__internal_3dcbf92960074b7a8c1236c0cb50a82935e0f67fa7f83d45b1a75c1637344c60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_3dcbf92960074b7a8c1236c0cb50a82935e0f67fa7f83d45b1a75c1637344c60->leave($__internal_3dcbf92960074b7a8c1236c0cb50a82935e0f67fa7f83d45b1a75c1637344c60_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_4b0c953e76a8ed4950776ca0da5e9e3f157bfb27e9d41e826d271e445898d058 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b0c953e76a8ed4950776ca0da5e9e3f157bfb27e9d41e826d271e445898d058->enter($__internal_4b0c953e76a8ed4950776ca0da5e9e3f157bfb27e9d41e826d271e445898d058_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_4b0c953e76a8ed4950776ca0da5e9e3f157bfb27e9d41e826d271e445898d058->leave($__internal_4b0c953e76a8ed4950776ca0da5e9e3f157bfb27e9d41e826d271e445898d058_prof);

    }

    // line 51
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_93fd5ff8b63971c68fd1c4fd952d5e2a41e7d264ba64d218eca46cb6d7c5dd50 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_93fd5ff8b63971c68fd1c4fd952d5e2a41e7d264ba64d218eca46cb6d7c5dd50->enter($__internal_93fd5ff8b63971c68fd1c4fd952d5e2a41e7d264ba64d218eca46cb6d7c5dd50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 52
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_93fd5ff8b63971c68fd1c4fd952d5e2a41e7d264ba64d218eca46cb6d7c5dd50->leave($__internal_93fd5ff8b63971c68fd1c4fd952d5e2a41e7d264ba64d218eca46cb6d7c5dd50_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 55,  201 => 54,  197 => 53,  192 => 52,  186 => 51,  175 => 44,  166 => 45,  164 => 44,  160 => 42,  154 => 41,  134 => 26,  128 => 22,  122 => 21,  111 => 19,  102 => 14,  97 => 13,  91 => 12,  79 => 11,  69 => 57,  67 => 51,  62 => 48,  60 => 41,  56 => 39,  54 => 21,  49 => 19,  42 => 16,  40 => 12,  36 => 11,  29 => 6,);
    }

    public function getSource()
    {
        return "{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>


{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
";
    }
}
