﻿using System;

public interface ICommand
{
    string Execute();
}
