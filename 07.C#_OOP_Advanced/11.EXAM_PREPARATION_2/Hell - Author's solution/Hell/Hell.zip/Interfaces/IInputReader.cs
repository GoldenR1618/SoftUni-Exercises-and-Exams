﻿using System;

public interface IInputReader
{
    string ReadLine();
}